import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/primary_button.dart';
import '../../../../core/widgets/pin_entry_sheet.dart';
import '../../../wallet/presentation/providers/wallet_provider.dart';
import '../providers/purchase_provider.dart';

const _discos = ['Ikeja Electric', 'Eko Electric', 'Abuja Electric', 'PHED', 'Kano Electric'];

class ElectricityScreen extends ConsumerStatefulWidget {
  const ElectricityScreen({super.key});
  @override
  ConsumerState<ElectricityScreen> createState() => _ElectricityScreenState();
}

class _ElectricityScreenState extends ConsumerState<ElectricityScreen> {
  String _disco = _discos.first;
  String _meterType = 'prepaid';
  final _meterCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  bool _submitting = false;

  Future<void> _submit() async {
    if (_meterCtrl.text.isEmpty || _amountCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter meter number and amount')));
      return;
    }
    final pin = await showPinEntrySheet(context);
    if (pin == null || !mounted) return;

    setState(() => _submitting = true);
    try {
      await ref.read(purchaseRepositoryProvider).payElectricity(
            disco: _disco, meterNumber: _meterCtrl.text.trim(),
            meterType: _meterType, amount: double.parse(_amountCtrl.text), pin: pin,
          );
      ref.invalidate(walletBalanceProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Electricity payment submitted successfully'), backgroundColor: AppColors.accentGreen),
        );
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Payment failed: ${e.toString()}'), backgroundColor: AppColors.error));
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Electricity Bill')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            DropdownButtonFormField<String>(
              value: _disco,
              decoration: const InputDecoration(labelText: 'Distribution Company'),
              items: _discos.map((d) => DropdownMenuItem(value: d, child: Text(d))).toList(),
              onChanged: (v) => setState(() => _disco = v!),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: RadioListTile<String>(
                    value: 'prepaid', groupValue: _meterType, title: const Text('Prepaid'),
                    onChanged: (v) => setState(() => _meterType = v!), activeColor: AppColors.primaryBlue,
                  ),
                ),
                Expanded(
                  child: RadioListTile<String>(
                    value: 'postpaid', groupValue: _meterType, title: const Text('Postpaid'),
                    onChanged: (v) => setState(() => _meterType = v!), activeColor: AppColors.primaryBlue,
                  ),
                ),
              ],
            ),
            TextField(
              controller: _meterCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Meter Number', prefixIcon: Icon(Icons.electric_meter_outlined)),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _amountCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Amount (₦)', prefixIcon: Icon(Icons.payments_outlined)),
            ),
            const SizedBox(height: 28),
            PrimaryButton(label: 'Pay Bill', isLoading: _submitting, onPressed: _submit),
          ],
        ),
      ),
    );
  }
}
