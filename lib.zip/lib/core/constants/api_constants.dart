class ApiConstants {
  ApiConstants._();

  // Point this to your deployed backend. Use --dart-define=API_BASE_URL=...
  // at build time to switch between dev/staging/production without editing code.
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:5000/api', // 10.0.2.2 = Android emulator's localhost
  );

  static const String register = '/auth/register';
  static const String login = '/auth/login';
  static const String refresh = '/auth/refresh';
  static const String me = '/auth/me';
  static const String setPin = '/auth/pin';

  static const String walletBalance = '/wallet/balance';
  static const String walletFund = '/wallet/fund';

  static const String buyData = '/purchase/data';
  static const String buyAirtime = '/purchase/airtime';
  static const String payElectricity = '/purchase/electricity';
  static const String cableTv = '/purchase/cable-tv';
  static const String examPin = '/purchase/exam-pin';

  static const String transactions = '/transactions';
  static const String referrals = '/referrals';
  static const String supportContacts = '/support/contacts';
}
