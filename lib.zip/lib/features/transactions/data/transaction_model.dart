class TransactionModel {
  final String id;
  final String reference;
  final String type;
  final String? category;
  final String? description;
  final double amount;
  final String status;
  final DateTime createdAt;

  TransactionModel({
    required this.id,
    required this.reference,
    required this.type,
    this.category,
    this.description,
    required this.amount,
    required this.status,
    required this.createdAt,
  });

  factory TransactionModel.fromJson(Map<String, dynamic> json) => TransactionModel(
        id: json['id'],
        reference: json['reference'],
        type: json['type'],
        category: json['category'],
        description: json['description'],
        amount: double.parse(json['amount'].toString()),
        status: json['status'],
        createdAt: DateTime.parse(json['created_at']),
      );
}
