import Flutter
import UIKit
import XCTest

class RunnerTests: XCTestCase {

  func testExample() {
    // A placeholder unit test — extend with real coverage as the app grows.
    XCTAssertTrue(true)
  }
}
