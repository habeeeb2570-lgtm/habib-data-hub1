import 'package:dio/dio.dart';
import '../../../core/constants/api_constants.dart';
import '../../../core/network/dio_client.dart';

class WalletRepository {
  final Dio _dio = DioClient.instance;

  Future<double> getBalance() async {
    final res = await _dio.get(ApiConstants.walletBalance);
    return double.parse(res.data['data']['balance'].toString());
  }

  /// Starts a funding session; returns the checkout URL (Paystack) or link (Flutterwave)
  /// to load into a WebView, plus the reference to verify afterwards.
  Future<Map<String, dynamic>> initiateFunding({required double amount, required String gateway}) async {
    final res = await _dio.post(ApiConstants.walletFund, data: {'amount': amount, 'gateway': gateway});
    return res.data['data'];
  }
}
