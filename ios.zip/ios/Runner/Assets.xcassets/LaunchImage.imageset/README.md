Replace LaunchImage, LaunchImage@2x and LaunchImage@3x with your own launch
image (e.g. your app logo). Sizes should be 1x/2x/3x variants of the same art.
