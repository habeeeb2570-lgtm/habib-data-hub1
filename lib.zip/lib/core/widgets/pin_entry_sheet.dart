import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import '../theme/app_colors.dart';

/// Bottom sheet that collects the user's 4-digit transaction PIN before any
/// spend is submitted. Returns the PIN string, or null if the user cancels.
Future<String?> showPinEntrySheet(BuildContext context) {
  final controller = TextEditingController();
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom, left: 24, right: 24, top: 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('Enter Transaction PIN', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('Confirm this purchase with your 4-digit PIN', style: TextStyle(color: AppColors.textMuted)),
          const SizedBox(height: 24),
          PinCodeTextField(
            appContext: ctx,
            length: 4,
            obscureText: true,
            keyboardType: TextInputType.number,
            animationType: AnimationType.fade,
            pinTheme: PinTheme(
              shape: PinCodeFieldShape.box,
              borderRadius: BorderRadius.circular(12),
              fieldHeight: 56,
              fieldWidth: 50,
              activeColor: AppColors.primaryBlue,
              selectedColor: AppColors.primaryBlue,
              inactiveColor: const Color(0xFFE4E7EC),
            ),
            controller: controller,
            onCompleted: (value) => Navigator.of(ctx).pop(value),
            onChanged: (_) {},
          ),
          const SizedBox(height: 24),
        ],
      ),
    ),
  );
}
