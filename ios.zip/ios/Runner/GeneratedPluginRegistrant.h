// Generated file. Do not edit.
// This file is regenerated automatically by `flutter pub get` /
// `flutter build` based on the plugins declared in pubspec.yaml.

#ifndef GeneratedPluginRegistrant_h
#define GeneratedPluginRegistrant_h

#import <Flutter/Flutter.h>

@interface GeneratedPluginRegistrant : NSObject
+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry;
@end

#endif /* GeneratedPluginRegistrant_h */
