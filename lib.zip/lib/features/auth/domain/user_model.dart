class UserModel {
  final String id;
  final String fullName;
  final String email;
  final String phone;
  final String referralCode;
  final String role;

  UserModel({
    required this.id,
    required this.fullName,
    required this.email,
    required this.phone,
    required this.referralCode,
    required this.role,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id: json['id'],
        fullName: json['full_name'] ?? '',
        email: json['email'] ?? '',
        phone: json['phone'] ?? '',
        referralCode: json['referral_code'] ?? '',
        role: json['role'] ?? 'user',
      );
}
