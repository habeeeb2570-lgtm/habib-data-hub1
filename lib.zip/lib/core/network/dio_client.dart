import 'package:dio/dio.dart';
import '../constants/api_constants.dart';
import 'token_storage.dart';

/// Single shared Dio instance: attaches the JWT to every request and
/// silently refreshes an expired access token once before failing.
class DioClient {
  static final Dio _dio = Dio(BaseOptions(
    baseUrl: ApiConstants.baseUrl,
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 20),
    headers: {'Content-Type': 'application/json'},
  ));

  static Dio get instance {
    if (_dio.interceptors.isEmpty) {
      _dio.interceptors.add(InterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await TokenStorage.getAccessToken();
          if (token != null) options.headers['Authorization'] = 'Bearer $token';
          handler.next(options);
        },
        onError: (error, handler) async {
          if (error.response?.statusCode == 401) {
            final refreshed = await _tryRefresh();
            if (refreshed != null) {
              final req = error.requestOptions;
              req.headers['Authorization'] = 'Bearer $refreshed';
              try {
                final response = await _dio.fetch(req);
                return handler.resolve(response);
              } catch (_) {
                // fall through to original error
              }
            }
          }
          handler.next(error);
        },
      ));
    }
    return _dio;
  }

  static Future<String?> _tryRefresh() async {
    try {
      final refreshToken = await TokenStorage.getRefreshToken();
      if (refreshToken == null) return null;
      final response = await Dio(BaseOptions(baseUrl: ApiConstants.baseUrl)).post(
        ApiConstants.refresh,
        data: {'refreshToken': refreshToken},
      );
      final newToken = response.data['data']['token'] as String;
      final existingRefresh = await TokenStorage.getRefreshToken();
      await TokenStorage.saveTokens(accessToken: newToken, refreshToken: existingRefresh!);
      return newToken;
    } catch (_) {
      await TokenStorage.clear();
      return null;
    }
  }
}
