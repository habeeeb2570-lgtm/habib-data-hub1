import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../../../core/theme/app_colors.dart';
import '../providers/transaction_provider.dart';

class TransactionsScreen extends ConsumerWidget {
  const TransactionsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final txAsync = ref.watch(transactionListProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Transaction History')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                decoration: const InputDecoration(
                  hintText: 'Search by reference or description',
                  prefixIcon: Icon(Icons.search),
                ),
                onChanged: (v) => ref.read(transactionSearchProvider.notifier).state = v,
              ),
            ),
            Expanded(
              child: txAsync.when(
                data: (transactions) {
                  if (transactions.isEmpty) {
                    return const Center(child: Text('No transactions found'));
                  }
                  return ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: transactions.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, i) {
                      final tx = transactions[i];
                      final statusColor = tx.status == 'successful'
                          ? AppColors.accentGreen
                          : tx.status == 'pending'
                              ? AppColors.warning
                              : AppColors.error;
                      return ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: CircleAvatar(
                          backgroundColor: statusColor.withOpacity(0.12),
                          child: Icon(_iconFor(tx.type), color: statusColor, size: 20),
                        ),
                        title: Text(tx.description ?? tx.type, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(DateFormat('MMM d, y • h:mm a').format(tx.createdAt)),
                        trailing: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('₦${tx.amount.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                            Text(tx.status, style: TextStyle(color: statusColor, fontSize: 11)),
                          ],
                        ),
                      );
                    },
                  );
                },
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Center(child: Text('Failed to load transactions')),
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _iconFor(String type) {
    switch (type) {
      case 'data': return Icons.wifi_rounded;
      case 'airtime': return Icons.phone_android_rounded;
      case 'electricity': return Icons.bolt_rounded;
      case 'cable_tv': return Icons.tv_rounded;
      case 'exam_pin': return Icons.school_rounded;
      case 'fund_wallet': return Icons.account_balance_wallet_rounded;
      default: return Icons.receipt_long_rounded;
    }
  }
}
