import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/transaction_model.dart';
import '../../data/transaction_repository.dart';

final transactionRepositoryProvider = Provider((ref) => TransactionRepository());

final transactionSearchProvider = StateProvider<String>((ref) => '');

final transactionListProvider = FutureProvider.autoDispose<List<TransactionModel>>((ref) {
  final search = ref.watch(transactionSearchProvider);
  return ref.read(transactionRepositoryProvider).list(search: search);
});
