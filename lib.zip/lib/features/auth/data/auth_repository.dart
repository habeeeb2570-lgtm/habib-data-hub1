import 'package:dio/dio.dart';
import '../../../core/constants/api_constants.dart';
import '../../../core/network/dio_client.dart';
import '../../../core/network/token_storage.dart';
import '../domain/user_model.dart';

class AuthRepository {
  final Dio _dio = DioClient.instance;

  Future<UserModel> register({
    required String fullName,
    required String email,
    required String phone,
    required String password,
    String? referralCode,
  }) async {
    final res = await _dio.post(ApiConstants.register, data: {
      'fullName': fullName,
      'email': email,
      'phone': phone,
      'password': password,
      if (referralCode != null && referralCode.isNotEmpty) 'referralCode': referralCode,
    });
    final data = res.data['data'];
    await TokenStorage.saveTokens(accessToken: data['token'], refreshToken: data['refreshToken']);
    return UserModel.fromJson(data['user']);
  }

  Future<UserModel> login({required String identifier, required String password}) async {
    final res = await _dio.post(ApiConstants.login, data: {
      'identifier': identifier,
      'password': password,
    });
    final data = res.data['data'];
    await TokenStorage.saveTokens(accessToken: data['token'], refreshToken: data['refreshToken']);
    return UserModel.fromJson(data['user']);
  }

  Future<UserModel> fetchMe() async {
    final res = await _dio.get(ApiConstants.me);
    return UserModel.fromJson(res.data['data']['user']);
  }

  Future<void> setTransactionPin(String pin) async {
    await _dio.post(ApiConstants.setPin, data: {'pin': pin});
  }

  Future<void> logout() async {
    await TokenStorage.clear();
  }
}
