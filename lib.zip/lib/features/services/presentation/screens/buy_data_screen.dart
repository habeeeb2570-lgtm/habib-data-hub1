import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/primary_button.dart';
import '../../../../core/widgets/pin_entry_sheet.dart';
import '../../../wallet/presentation/providers/wallet_provider.dart';
import '../providers/purchase_provider.dart';

const _networks = ['MTN', 'AIRTEL', 'GLO', '9MOBILE'];

// In production, fetch live plans per network from GET /admin/service-plans
// (public read variant) instead of hardcoding — this keeps admin pricing in sync.
const _samplePlans = {
  'MTN': [
    {'code': 'mtn-1gb-30d', 'label': '1GB - 30 Days', 'price': 350.0},
    {'code': 'mtn-2gb-30d', 'label': '2GB - 30 Days', 'price': 650.0},
    {'code': 'mtn-5gb-30d', 'label': '5GB - 30 Days', 'price': 1500.0},
  ],
  'AIRTEL': [
    {'code': 'airtel-1gb-30d', 'label': '1GB - 30 Days', 'price': 340.0},
    {'code': 'airtel-3gb-30d', 'label': '3GB - 30 Days', 'price': 900.0},
  ],
  'GLO': [
    {'code': 'glo-1.5gb-30d', 'label': '1.5GB - 30 Days', 'price': 300.0},
    {'code': 'glo-5.8gb-30d', 'label': '5.8GB - 30 Days', 'price': 1500.0},
  ],
  '9MOBILE': [
    {'code': '9mobile-1.5gb-30d', 'label': '1.5GB - 30 Days', 'price': 300.0},
  ],
};

class BuyDataScreen extends ConsumerStatefulWidget {
  const BuyDataScreen({super.key});
  @override
  ConsumerState<BuyDataScreen> createState() => _BuyDataScreenState();
}

class _BuyDataScreenState extends ConsumerState<BuyDataScreen> {
  String _network = _networks.first;
  Map<String, dynamic>? _selectedPlan;
  final _phoneCtrl = TextEditingController();
  bool _submitting = false;

  Future<void> _submit() async {
    if (_selectedPlan == null || _phoneCtrl.text.length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select a plan and enter phone number')));
      return;
    }
    final pin = await showPinEntrySheet(context);
    if (pin == null || !mounted) return;

    setState(() => _submitting = true);
    try {
      await ref.read(purchaseRepositoryProvider).buyData(
            network: _network, phone: _phoneCtrl.text.trim(),
            planCode: _selectedPlan!['code'], pin: pin,
          );
      ref.invalidate(walletBalanceProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Data purchase submitted successfully'), backgroundColor: AppColors.accentGreen),
        );
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Purchase failed: ${e.toString()}'), backgroundColor: AppColors.error));
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final plans = _samplePlans[_network]!;
    return Scaffold(
      appBar: AppBar(title: const Text('Buy Data')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('Select Network', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              children: _networks.map((n) {
                final selected = n == _network;
                return ChoiceChip(
                  label: Text(n),
                  selected: selected,
                  onSelected: (_) => setState(() { _network = n; _selectedPlan = null; }),
                  selectedColor: AppColors.primaryBlue,
                  labelStyle: TextStyle(color: selected ? Colors.white : null),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Phone Number', prefixIcon: Icon(Icons.phone_outlined)),
            ),
            const SizedBox(height: 20),
            const Text('Select Plan', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            ...plans.map((p) => Card(
                  child: RadioListTile<String>(
                    value: p['code'] as String,
                    groupValue: _selectedPlan?['code'] as String?,
                    onChanged: (_) => setState(() => _selectedPlan = p),
                    title: Text(p['label'] as String),
                    subtitle: Text('₦${(p['price'] as double).toStringAsFixed(0)}'),
                    activeColor: AppColors.primaryBlue,
                  ),
                )),
            const SizedBox(height: 20),
            PrimaryButton(label: 'Buy Data', isLoading: _submitting, onPressed: _submit),
          ],
        ),
      ),
    );
  }
}
