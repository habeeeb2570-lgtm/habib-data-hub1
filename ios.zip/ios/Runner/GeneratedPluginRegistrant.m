// Generated file. Do not edit.
// This file is regenerated automatically by `flutter pub get` /
// `flutter build` based on the plugins declared in pubspec.yaml.

#import "GeneratedPluginRegistrant.h"

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  // Populated automatically once `flutter pub get` has run.
}

@end
