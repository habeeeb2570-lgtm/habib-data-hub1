import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/primary_button.dart';
import '../providers/wallet_provider.dart';
import 'payment_webview_screen.dart';

class FundWalletScreen extends ConsumerStatefulWidget {
  const FundWalletScreen({super.key});
  @override
  ConsumerState<FundWalletScreen> createState() => _FundWalletScreenState();
}

class _FundWalletScreenState extends ConsumerState<FundWalletScreen> {
  final _amountCtrl = TextEditingController();
  String _gateway = 'paystack';
  bool _submitting = false;

  Future<void> _submit() async {
    final amount = double.tryParse(_amountCtrl.text);
    if (amount == null || amount < 100) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid amount (minimum ₦100)')));
      return;
    }
    setState(() => _submitting = true);
    try {
      final session = await ref.read(walletRepositoryProvider).initiateFunding(amount: amount, gateway: _gateway);
      final checkoutUrl = _gateway == 'paystack' ? session['authorization_url'] as String : session['link'] as String;

      if (!mounted) return;
      final completed = await Navigator.of(context).push<bool>(MaterialPageRoute(
        builder: (_) => PaymentWebViewScreen(
          checkoutUrl: checkoutUrl,
          callbackUrlPrefix: 'wallet/verify/$_gateway',
        ),
      ));
      if (completed == true) {
        ref.invalidate(walletBalanceProvider);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Wallet funded successfully'), backgroundColor: AppColors.accentGreen),
          );
          Navigator.of(context).pop();
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not start payment: ${e.toString()}'), backgroundColor: AppColors.error));
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Fund Wallet')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            TextField(
              controller: _amountCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Amount (₦)', prefixIcon: Icon(Icons.payments_outlined)),
            ),
            const SizedBox(height: 20),
            const Text('Payment Method', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            RadioListTile<String>(
              value: 'paystack', groupValue: _gateway, title: const Text('Paystack'),
              onChanged: (v) => setState(() => _gateway = v!), activeColor: AppColors.primaryBlue,
            ),
            RadioListTile<String>(
              value: 'flutterwave', groupValue: _gateway, title: const Text('Flutterwave'),
              onChanged: (v) => setState(() => _gateway = v!), activeColor: AppColors.primaryBlue,
            ),
            const SizedBox(height: 24),
            PrimaryButton(label: 'Proceed to Pay', isLoading: _submitting, onPressed: _submit),
          ],
        ),
      ),
    );
  }
}
