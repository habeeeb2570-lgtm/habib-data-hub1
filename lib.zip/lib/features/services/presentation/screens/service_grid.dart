import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import 'buy_data_screen.dart';
import 'buy_airtime_screen.dart';
import 'electricity_screen.dart';
import 'cable_tv_screen.dart';
import 'exam_pin_screen.dart';
import '../../../referral/presentation/screens/referral_screen.dart';
import '../../../support/presentation/screens/support_screen.dart';

class _ServiceItem {
  final String label;
  final IconData icon;
  final Color color;
  final Widget Function() screenBuilder;
  const _ServiceItem(this.label, this.icon, this.color, this.screenBuilder);
}

/// The main 2x4 grid of VTU services shown on the dashboard home tab.
class ServiceGrid extends StatelessWidget {
  const ServiceGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final items = <_ServiceItem>[
      _ServiceItem('Airtime', Icons.phone_android_rounded, AppColors.primaryBlue, () => const BuyAirtimeScreen()),
      _ServiceItem('Data', Icons.wifi_rounded, AppColors.accentGreen, () => const BuyDataScreen()),
      _ServiceItem('Electricity', Icons.bolt_rounded, AppColors.warning, () => const ElectricityScreen()),
      _ServiceItem('Cable TV', Icons.tv_rounded, AppColors.primaryBlue, () => const CableTvScreen()),
      _ServiceItem('WAEC/NECO', Icons.school_rounded, AppColors.accentGreen, () => const ExamPinScreen(examType: 'WAEC')),
      _ServiceItem('JAMB PIN', Icons.confirmation_number_rounded, AppColors.deepBlue, () => const ExamPinScreen(examType: 'JAMB')),
      _ServiceItem('Referrals', Icons.card_giftcard_rounded, AppColors.accentGreen, () => const ReferralScreen()),
      _ServiceItem('Support', Icons.headset_mic_rounded, AppColors.primaryBlue, () => const SupportScreen()),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 16,
        crossAxisSpacing: 12,
        childAspectRatio: 0.78,
      ),
      itemBuilder: (context, i) {
        final item = items[i];
        return InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => item.screenBuilder())),
          child: Column(
            children: [
              Container(
                height: 56, width: 56,
                decoration: BoxDecoration(color: item.color.withOpacity(0.12), shape: BoxShape.circle),
                child: Icon(item.icon, color: item.color),
              ),
              const SizedBox(height: 8),
              Text(item.label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5)),
            ],
          ),
        );
      },
    );
  }
}
