import 'package:dio/dio.dart';
import '../../../core/constants/api_constants.dart';
import '../../../core/network/dio_client.dart';

/// One repository for every VTU purchase type — each method mirrors a
/// backend /api/purchase/* endpoint and returns the created transaction.
class PurchaseRepository {
  final Dio _dio = DioClient.instance;

  Future<Map<String, dynamic>> buyData({
    required String network, required String phone, required String planCode, required String pin,
  }) async {
    final res = await _dio.post(ApiConstants.buyData, data: {
      'network': network, 'phone': phone, 'planCode': planCode, 'pin': pin,
    });
    return res.data['data'];
  }

  Future<Map<String, dynamic>> buyAirtime({
    required String network, required String phone, required double amount, required String pin,
  }) async {
    final res = await _dio.post(ApiConstants.buyAirtime, data: {
      'network': network, 'phone': phone, 'amount': amount, 'pin': pin,
    });
    return res.data['data'];
  }

  Future<Map<String, dynamic>> payElectricity({
    required String disco, required String meterNumber, required String meterType,
    required double amount, required String pin,
  }) async {
    final res = await _dio.post(ApiConstants.payElectricity, data: {
      'disco': disco, 'meterNumber': meterNumber, 'meterType': meterType, 'amount': amount, 'pin': pin,
    });
    return res.data['data'];
  }

  Future<Map<String, dynamic>> subscribeCableTv({
    required String provider, required String smartCardNumber, required String planCode, required String pin,
  }) async {
    final res = await _dio.post(ApiConstants.cableTv, data: {
      'provider': provider, 'smartCardNumber': smartCardNumber, 'planCode': planCode, 'pin': pin,
    });
    return res.data['data'];
  }

  Future<Map<String, dynamic>> buyExamPin({
    required String examType, required String planCode, int quantity = 1, required String pin,
  }) async {
    final res = await _dio.post(ApiConstants.examPin, data: {
      'examType': examType, 'planCode': planCode, 'quantity': quantity, 'pin': pin,
    });
    return res.data['data'];
  }
}
