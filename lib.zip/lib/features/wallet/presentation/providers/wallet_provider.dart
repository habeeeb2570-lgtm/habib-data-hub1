import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/wallet_repository.dart';

final walletRepositoryProvider = Provider((ref) => WalletRepository());

final walletBalanceProvider = FutureProvider.autoDispose<double>((ref) {
  return ref.read(walletRepositoryProvider).getBalance();
});
