import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/primary_button.dart';
import '../../../../core/widgets/pin_entry_sheet.dart';
import '../../../wallet/presentation/providers/wallet_provider.dart';
import '../providers/purchase_provider.dart';

const _samplePlans = {
  'WAEC': [{'code': 'waec-result-checker', 'label': 'WAEC Result Checker PIN', 'price': 3500.0}],
  'NECO': [{'code': 'neco-result-checker', 'label': 'NECO Result Checker PIN', 'price': 1300.0}],
  'JAMB': [{'code': 'jamb-utme', 'label': 'JAMB UTME PIN', 'price': 6200.0}],
};

class ExamPinScreen extends ConsumerStatefulWidget {
  final String examType; // WAEC | NECO | JAMB
  const ExamPinScreen({super.key, required this.examType});
  @override
  ConsumerState<ExamPinScreen> createState() => _ExamPinScreenState();
}

class _ExamPinScreenState extends ConsumerState<ExamPinScreen> {
  late String _examType = widget.examType;
  Map<String, dynamic>? _selectedPlan;
  int _quantity = 1;
  bool _submitting = false;

  Future<void> _submit() async {
    if (_selectedPlan == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select a PIN type')));
      return;
    }
    final pin = await showPinEntrySheet(context);
    if (pin == null || !mounted) return;

    setState(() => _submitting = true);
    try {
      await ref.read(purchaseRepositoryProvider).buyExamPin(
            examType: _examType, planCode: _selectedPlan!['code'], quantity: _quantity, pin: pin,
          );
      ref.invalidate(walletBalanceProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('PIN purchase submitted successfully'), backgroundColor: AppColors.accentGreen),
        );
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Purchase failed: ${e.toString()}'), backgroundColor: AppColors.error));
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final plans = _samplePlans[_examType]!;
    return Scaffold(
      appBar: AppBar(title: const Text('Exam PIN')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('Select Exam Body', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              children: _samplePlans.keys.map((e) {
                final selected = e == _examType;
                return ChoiceChip(
                  label: Text(e),
                  selected: selected,
                  onSelected: (_) => setState(() { _examType = e; _selectedPlan = null; }),
                  selectedColor: AppColors.primaryBlue,
                  labelStyle: TextStyle(color: selected ? Colors.white : null),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            ...plans.map((p) => Card(
                  child: RadioListTile<String>(
                    value: p['code'] as String,
                    groupValue: _selectedPlan?['code'] as String?,
                    onChanged: (_) => setState(() => _selectedPlan = p),
                    title: Text(p['label'] as String),
                    subtitle: Text('₦${(p['price'] as double).toStringAsFixed(0)} per PIN'),
                    activeColor: AppColors.primaryBlue,
                  ),
                )),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Quantity', style: TextStyle(fontWeight: FontWeight.w600)),
                Row(
                  children: [
                    IconButton(onPressed: () => setState(() => _quantity = _quantity > 1 ? _quantity - 1 : 1), icon: const Icon(Icons.remove_circle_outline)),
                    Text('$_quantity', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    IconButton(onPressed: () => setState(() => _quantity++), icon: const Icon(Icons.add_circle_outline)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            PrimaryButton(label: 'Buy PIN', isLoading: _submitting, onPressed: _submit),
          ],
        ),
      ),
    );
  }
}
