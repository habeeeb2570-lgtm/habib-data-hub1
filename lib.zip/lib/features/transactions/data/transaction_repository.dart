import 'package:dio/dio.dart';
import '../../../core/constants/api_constants.dart';
import '../../../core/network/dio_client.dart';
import 'transaction_model.dart';

class TransactionRepository {
  final Dio _dio = DioClient.instance;

  Future<List<TransactionModel>> list({String? search, String? type, int page = 1}) async {
    final res = await _dio.get(ApiConstants.transactions, queryParameters: {
      'page': page,
      if (search != null && search.isNotEmpty) 'search': search,
      if (type != null) 'type': type,
    });
    final List data = res.data['data'];
    return data.map((e) => TransactionModel.fromJson(e)).toList();
  }
}
