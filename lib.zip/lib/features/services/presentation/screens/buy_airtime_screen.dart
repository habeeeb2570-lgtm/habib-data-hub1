import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/primary_button.dart';
import '../../../../core/widgets/pin_entry_sheet.dart';
import '../../data/purchase_repository.dart';
import '../../../wallet/presentation/providers/wallet_provider.dart';
import '../providers/purchase_provider.dart';

const _networks = ['MTN', 'AIRTEL', 'GLO', '9MOBILE'];

class BuyAirtimeScreen extends ConsumerStatefulWidget {
  const BuyAirtimeScreen({super.key});
  @override
  ConsumerState<BuyAirtimeScreen> createState() => _BuyAirtimeScreenState();
}

class _BuyAirtimeScreenState extends ConsumerState<BuyAirtimeScreen> {
  String _network = _networks.first;
  final _phoneCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  bool _submitting = false;

  Future<void> _submit() async {
    if (_phoneCtrl.text.length < 10 || _amountCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid phone number and amount')));
      return;
    }
    final pin = await showPinEntrySheet(context);
    if (pin == null || !mounted) return;

    setState(() => _submitting = true);
    try {
      await ref.read(purchaseRepositoryProvider).buyAirtime(
            network: _network, phone: _phoneCtrl.text.trim(),
            amount: double.parse(_amountCtrl.text), pin: pin,
          );
      ref.invalidate(walletBalanceProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Airtime purchase submitted successfully'), backgroundColor: AppColors.accentGreen),
        );
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Purchase failed: ${e.toString()}'), backgroundColor: AppColors.error));
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Buy Airtime')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('Select Network', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              children: _networks.map((n) {
                final selected = n == _network;
                return ChoiceChip(
                  label: Text(n),
                  selected: selected,
                  onSelected: (_) => setState(() => _network = n),
                  selectedColor: AppColors.primaryBlue,
                  labelStyle: TextStyle(color: selected ? Colors.white : null),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Phone Number', prefixIcon: Icon(Icons.phone_outlined)),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _amountCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Amount (₦)', prefixIcon: Icon(Icons.payments_outlined)),
            ),
            const SizedBox(height: 28),
            PrimaryButton(label: 'Buy Airtime', isLoading: _submitting, onPressed: _submit),
          ],
        ),
      ),
    );
  }
}
