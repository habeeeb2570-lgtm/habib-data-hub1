// Basic smoke test — extend with real widget/unit tests as features solidify.
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:habib_data_hub/main.dart';

void main() {
  testWidgets('App boots and shows the splash screen', (WidgetTester tester) async {
    await tester.pumpWidget(const ProviderScope(child: HabibDataHubApp()));
    // The splash screen shows the app name while auth state resolves.
    expect(find.text('Habib Data Hub'), findsOneWidget);
  });
}
