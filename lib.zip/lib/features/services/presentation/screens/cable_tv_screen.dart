import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/primary_button.dart';
import '../../../../core/widgets/pin_entry_sheet.dart';
import '../../../wallet/presentation/providers/wallet_provider.dart';
import '../providers/purchase_provider.dart';

const _providers = ['DSTV', 'GOTV', 'STARTIMES'];

const _samplePlans = {
  'DSTV': [
    {'code': 'dstv-padi', 'label': 'DStv Padi', 'price': 3600.0},
    {'code': 'dstv-compact', 'label': 'DStv Compact', 'price': 19000.0},
  ],
  'GOTV': [
    {'code': 'gotv-jinja', 'label': 'GOtv Jinja', 'price': 3900.0},
    {'code': 'gotv-max', 'label': 'GOtv Max', 'price': 8500.0},
  ],
  'STARTIMES': [
    {'code': 'startimes-nova', 'label': 'Nova', 'price': 1900.0},
    {'code': 'startimes-classic', 'label': 'Classic', 'price': 3700.0},
  ],
};

class CableTvScreen extends ConsumerStatefulWidget {
  const CableTvScreen({super.key});
  @override
  ConsumerState<CableTvScreen> createState() => _CableTvScreenState();
}

class _CableTvScreenState extends ConsumerState<CableTvScreen> {
  String _provider = _providers.first;
  Map<String, dynamic>? _selectedPlan;
  final _smartCardCtrl = TextEditingController();
  bool _submitting = false;

  Future<void> _submit() async {
    if (_selectedPlan == null || _smartCardCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select a plan and enter smart card number')));
      return;
    }
    final pin = await showPinEntrySheet(context);
    if (pin == null || !mounted) return;

    setState(() => _submitting = true);
    try {
      await ref.read(purchaseRepositoryProvider).subscribeCableTv(
            provider: _provider, smartCardNumber: _smartCardCtrl.text.trim(),
            planCode: _selectedPlan!['code'], pin: pin,
          );
      ref.invalidate(walletBalanceProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Subscription submitted successfully'), backgroundColor: AppColors.accentGreen),
        );
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Subscription failed: ${e.toString()}'), backgroundColor: AppColors.error));
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final plans = _samplePlans[_provider]!;
    return Scaffold(
      appBar: AppBar(title: const Text('Cable TV Subscription')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('Select Provider', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              children: _providers.map((p) {
                final selected = p == _provider;
                return ChoiceChip(
                  label: Text(p),
                  selected: selected,
                  onSelected: (_) => setState(() { _provider = p; _selectedPlan = null; }),
                  selectedColor: AppColors.primaryBlue,
                  labelStyle: TextStyle(color: selected ? Colors.white : null),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _smartCardCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Smart Card / IUC Number', prefixIcon: Icon(Icons.credit_card)),
            ),
            const SizedBox(height: 20),
            const Text('Select Package', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            ...plans.map((p) => Card(
                  child: RadioListTile<String>(
                    value: p['code'] as String,
                    groupValue: _selectedPlan?['code'] as String?,
                    onChanged: (_) => setState(() => _selectedPlan = p),
                    title: Text(p['label'] as String),
                    subtitle: Text('₦${(p['price'] as double).toStringAsFixed(0)}'),
                    activeColor: AppColors.primaryBlue,
                  ),
                )),
            const SizedBox(height: 20),
            PrimaryButton(label: 'Subscribe', isLoading: _submitting, onPressed: _submit),
          ],
        ),
      ),
    );
  }
}
