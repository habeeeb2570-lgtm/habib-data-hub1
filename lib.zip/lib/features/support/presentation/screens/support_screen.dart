import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/constants/api_constants.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  Future<Map<String, dynamic>> _loadContacts() async {
    final res = await DioClient.instance.get(ApiConstants.supportContacts);
    return res.data['data'];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Customer Support')),
      body: SafeArea(
        child: FutureBuilder<Map<String, dynamic>>(
          future: _loadContacts(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
            final contacts = snapshot.data!;
            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text('Need help? Reach us instantly:', style: TextStyle(fontSize: 16)),
                const SizedBox(height: 20),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.chat, color: AppColors.accentGreen),
                    title: const Text('Chat on WhatsApp'),
                    subtitle: const Text('Fastest response'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => launchUrl(Uri.parse(contacts['whatsapp']), mode: LaunchMode.externalApplication),
                  ),
                ),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.email_outlined, color: AppColors.primaryBlue),
                    title: const Text('Email Support'),
                    subtitle: Text(contacts['email']),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => launchUrl(Uri.parse('mailto:${contacts['email']}')),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
