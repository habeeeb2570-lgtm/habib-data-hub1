import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/purchase_repository.dart';

final purchaseRepositoryProvider = Provider((ref) => PurchaseRepository());
