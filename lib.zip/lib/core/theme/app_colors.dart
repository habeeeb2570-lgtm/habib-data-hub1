import 'package:flutter/material.dart';

/// Habib Data Hub brand palette — blue (trust/finance), green (money/success),
/// white (clean, modern surfaces).
class AppColors {
  AppColors._();

  static const Color primaryBlue = Color(0xFF0B5FFF);
  static const Color deepBlue = Color(0xFF063D9E);
  static const Color accentGreen = Color(0xFF1FAA59);
  static const Color lightGreen = Color(0xFFE6F7EC);
  static const Color white = Color(0xFFFFFFFF);
  static const Color offWhite = Color(0xFFF5F8FF);

  static const Color textDark = Color(0xFF101828);
  static const Color textMuted = Color(0xFF667085);

  static const Color error = Color(0xFFE0333D);
  static const Color warning = Color(0xFFF5A623);

  // Dark mode surfaces
  static const Color darkBg = Color(0xFF0D1117);
  static const Color darkSurface = Color(0xFF161B22);
  static const Color darkTextMuted = Color(0xFF9AA4B2);

  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primaryBlue, deepBlue],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient balanceGradient = LinearGradient(
    colors: [Color(0xFF0B5FFF), Color(0xFF1FAA59)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
