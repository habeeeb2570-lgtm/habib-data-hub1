import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// Loads the Paystack/Flutterwave checkout page. When the browser navigates
/// to our callback URL, we pop and tell the caller to verify & refresh balance.
class PaymentWebViewScreen extends StatefulWidget {
  final String checkoutUrl;
  final String callbackUrlPrefix;
  const PaymentWebViewScreen({super.key, required this.checkoutUrl, required this.callbackUrlPrefix});

  @override
  State<PaymentWebViewScreen> createState() => _PaymentWebViewScreenState();
}

class _PaymentWebViewScreenState extends State<PaymentWebViewScreen> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (request) {
          if (request.url.startsWith(widget.callbackUrlPrefix)) {
            Navigator.of(context).pop(true); // payment flow reached our callback
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..loadRequest(Uri.parse(widget.checkoutUrl));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Complete Payment')),
      body: WebViewWidget(controller: _controller),
    );
  }
}
